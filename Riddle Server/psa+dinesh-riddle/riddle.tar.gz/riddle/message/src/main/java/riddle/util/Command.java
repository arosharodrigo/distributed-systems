package riddle.util;

/**
 * @author: prabath
 */
public class Command {

    public static final String HELLO = "hello";

    public static final String RIDDLE = "riddle";

    public static final String ANSWER = "answer";

    public static final String BYE = "bye";
}
