package riddle.service;

/**
 * @author: prabath
 */
public interface ChannelChangeListener {

    void notifyChannelClose();
}
