package riddle.source;

/**
 * @author: prabath
 */
public interface MSgSource {

    void readMsg();

}
