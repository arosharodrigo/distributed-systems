package main.java.output;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: arosha
 * Date: 3/30/14
 * Time: 6:49 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Screen {

    String print(String out) throws IOException;

}
