README
======

JDK version - 1.7

1. Start main methods of UDP server and UDP client classes.
2. Start main methods of TCP server and TCP client classes.

Note: Additional port and server-ip configurations added to initial response.
If you do not want to change the default one just press enter
to skip into actual riddle server.