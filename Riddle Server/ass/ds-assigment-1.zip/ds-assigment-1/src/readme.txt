JDK version - 1.7.0

To start TCP server
 java -cp out/production/ds-assigment-1/ server.TcpServer

To start TCP client
 java -cp out/production/ds-assigment-1/ server.TcpClient

To start UDP server
 java -cp out/production/ds-assigment-1/ server.UdpServer

To start UDP client
 java -cp out/production/ds-assigment-1/ server.UdpClient