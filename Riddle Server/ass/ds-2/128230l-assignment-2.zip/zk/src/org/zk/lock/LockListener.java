package org.zk.lock;

public interface LockListener {

    public void lockAcquired();

}
