Software dependencies
=====================

JDK - 1.6
Apache zookeeper - 3.4.3



Run org.zk.lock.client.LockTestRunner to simulate read write lock with 5 clients

Run org.zk.election.client.Client to simulate leader election with 5 clients